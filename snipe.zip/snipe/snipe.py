"""
Requirements
python-opencv
numpy
socket
"""
import cv2

def sniper(x,y,w,h, image, color=None):
    """
    x, y are coordinates
    w, h are width and height 
    """
    x_rec_from, y_rec_from  = x,y
    x_rec_to, y_rec_to =w, h
    #scale factor for length of the lines
    x_scale_factor = int((x_rec_to - x_rec_from)/ 100 * 20)
    y_scale_factor = int((y_rec_to - y_rec_from)/ 100 * 20)
    if color == None:
        color = (0,100,255)
    # ##Left side
    xl1, yl1, xr2, yr2 = x_rec_from, y_rec_from, x_rec_from, y_rec_from + y_scale_factor
    xlo2, ylo2, xud2, yud2 = x_rec_from, y_rec_to - y_scale_factor, x_rec_from, y_rec_to ## for ouy ylo2 - yr2//2 + yr2
    xu1, yu1, xd2, yd2 = x_rec_from, y_rec_from, x_rec_from + x_scale_factor, y_rec_from
    xud1, yud1, xru2, yru2 =x_rec_from,y_rec_to, x_rec_from + x_scale_factor, y_rec_to
    # ##right side variables
    lx1, ly1, rx2, ry2 = x_rec_to, y_rec_from, x_rec_to, y_rec_from + y_scale_factor
    rxx2, ryy2, rxd2, ryd2 = x_rec_to, y_rec_to - y_scale_factor, x_rec_to, y_rec_to
    ux1, uy1, dx2, dy2 = x_rec_to, y_rec_from, x_rec_to - x_scale_factor, y_rec_from     ###for optional oux =(dx2 -xru2)/2
    dxd2, dyd2, x2r, y2r = x_rec_to, y_rec_to, x_rec_to - x_scale_factor, y_rec_to
    # line width
    line_width = 2
    # draw the lines
    line1 =cv2.line(image,(xl1,yl1), (xr2,yr2), color, line_width)
    line2 =cv2.line(image,(xlo2,ylo2), (xud2,yud2), color, line_width)
    line3 =cv2.line(image,(lx1,ly1), (rx2,ry2), color, line_width)
    line4 =cv2.line(image,(rxx2,ryy2), (rxd2,ryd2), color, line_width)
    line5 =cv2.line(image,(xu1,yu1), (xd2,yd2), color, line_width)
    line6 =cv2.line(image,(xud1,yud1), (xru2,yru2), color, line_width)
    line7 =cv2.line(image,(ux1,uy1), (dx2,dy2), color, line_width)
    line8 =cv2.line(image,(dxd2,dyd2), (x2r,y2r), color, line_width)
    return line1,line2,line3,line4,line5,line6,line7,line8

def four_snipy(x,y,w,h,image,color=None):

    x_rec_from, y_rec_from  = x,y
    x_rec_to, y_rec_to =w, h
    my_scale_factor = int((x_rec_to - x_rec_from)/ 100 * 6)
    if color == None:
        color = (0,100,255)
    line_width = 2
    
    oux =((x_rec_to - x_rec_from) // 2) + x_rec_from # origin-up line for x vertex
    xux,xuy,xudx,xudy = oux,y_rec_from - my_scale_factor, oux, y_rec_from + my_scale_factor
    xdx,xdy,xddx,xddy = oux,y_rec_to + my_scale_factor, oux, y_rec_to - my_scale_factor
    ## for ouy
    ouy = ((y_rec_to - y_rec_from) // 2) + y_rec_from # origin-sideways line for y vertex
    xlx, xly, xlrx,xlry = x_rec_from - my_scale_factor, ouy, x_rec_from + my_scale_factor, ouy
    xrx, xry, xrrx,xrry = x_rec_to + my_scale_factor, ouy, x_rec_to - my_scale_factor, ouy
    line1 =cv2.line(image,(xux,xuy), (xudx,xudy), color,line_width)
    line2 =cv2.line(image,(xdx,xdy), (xddx,xddy), color,line_width)
    line3 =cv2.line(image,(xlx,xly), (xlrx,xlry), color,line_width)
    line4 =cv2.line(image,(xrx,xry), (xrrx,xrry), color,line_width)

    return line1, line2, line3, line4

def target_locked(x,y,w,h,image,color=None,cross_not=None):
    if color == None:
        color = (0,100,255)
    line_width = 2
    x_rec_from, y_rec_from = x,y
    x_rec_to, y_rec_to =w, h
    my_scale_factor = int((x_rec_to - x_rec_from)/ 100 * 10)
    radius = x_rec_to - y_rec_to
    center_diag_x = int((x_rec_from + x_rec_to)/2)
    center_diag_y = int((y_rec_to + y_rec_from) /2)
    radius_d = y_rec_to - center_diag_y
    ## for oux
    oux =((x_rec_to - x_rec_from) // 2) + x_rec_from # origin-up line for x vertex
    xux,xuy,xudx,xudy = oux,y_rec_from - my_scale_factor, oux, y_rec_from + my_scale_factor
    xdx,xdy,xddx,xddy = oux,y_rec_to + my_scale_factor, oux, y_rec_to - my_scale_factor
    ## for ouy
    ouy = ((y_rec_to - y_rec_from) // 2) + y_rec_from # origin-sideways line for y vertex
    xlx, xly, xlrx,xlry = x_rec_from - my_scale_factor, ouy, x_rec_from + my_scale_factor, ouy
    xrx, xry, xrrx,xrry = x_rec_to + my_scale_factor, ouy, x_rec_to - my_scale_factor, ouy
    
    line1 = cv2.line(image,(xux,xuy), (xudx,xudy), color,line_width)
    line2 = cv2.line(image,(xdx,xdy), (xddx,xddy), color,line_width)
    line3 = cv2.line(image,(xlx,xly), (xlrx,xlry), color,line_width)
    line4 = cv2.line(image,(xrx,xry), (xrrx,xrry), color,line_width)
    target_circle = cv2.circle(image, (center_diag_x,center_diag_y),radius_d, color,line_width)
    #small circle radius
    small_radius = (x_rec_to - x_rec_from) // 4
    #small cross scale factors  
    cross_x_scale_factor = int((x_rec_to - x_rec_from)/ 100 * 6)
    cross_y_scale_factor = int((y_rec_to - y_rec_from)/ 100 * 6)
    if cross_not == 'small_circle':
        small_circle = cv2.circle(image,(center_diag_x,center_diag_y),small_radius,color,thickness=-2)
        return line1, line2,line3,line4, target_circle,small_circle
    elif cross_not == 'small_cross':
        line_c1 =cv2.line(image,(center_diag_x,center_diag_y), (center_diag_x-cross_x_scale_factor,center_diag_y), color)
        line_c2 = cv2.line(image,(center_diag_x,center_diag_y), (center_diag_x+cross_x_scale_factor,center_diag_y), color)
        line_c3 = cv2.line(image,(center_diag_x,center_diag_y), (center_diag_x,center_diag_y-cross_y_scale_factor), color)
        line_c4 = cv2.line(image,(center_diag_x,center_diag_y), (center_diag_x,center_diag_y+cross_y_scale_factor), color)
        return line1, line2,line3,line4, target_circle,line_c1,line_c2,line_c3,line_c4

    return line1, line2,line3,line4, target_circle


def recorder(x,y,image,action_type=None,color=None,shape_type=None):
    """
    Can be used to show 
    record, offline, online
    by setting the action type e.g:
    @action_type = online
    or provide any text you want be displayed
    @color is used to set the rectangle color
    @shape_type can be set to sniper e.g shape_type='sniper' or left out to default settings
    """
    font =cv2.FONT_HERSHEY_COMPLEX_SMALL
    rec_radius = 6
    green = (92, 159, 21)
    orange = (59, 175, 231)
    red = (47, 57, 211)
    # white = (255,255,255)
    # active = (109,207,142)
    # black = (40, 41, 35)
    # active = (109,207,142)
    rectangle =cv2.rectangle(image, (3, 3), (y-3,x-3),color,2)
    if action_type == 'record':
        rec = 'Rec'
        text = cv2.putText(image, "{}".format(rec),
        (45, 30), font, 1.0, (126, 161, 167), 1)
        circle = cv2.circle(image,(30,22), rec_radius, color=red,thickness=-1)
        return text,circle, rectangle
    elif action_type == 'online':
        rec = 'Online'
        text = cv2.putText(image, "{}".format(rec),
                           (45, 30), font, 1.0, (126, 161, 167), 1)
        circle = cv2.circle(image,(30,22), rec_radius, color=green,thickness=-1)
        return text,circle, rectangle
    elif action_type == 'offline':
        rec = 'Offline'
        text = cv2.putText(image, "{}".format(rec),
                           (45, 30), font, 1.0, (126, 161, 167), 1)
        circle = cv2.circle(image,(30,22), rec_radius, color=orange,thickness=-1)
        return text,circle, rectangle
    elif action_type == None:
        rec = 'Active'
        text = cv2.putText(image, "{}".format(rec),
                           (45, 30), font, 1.0, (126, 161, 167), 1)
        circle = cv2.circle(image,(30,22), rec_radius, color=green,thickness=-1)
        return text,circle, rectangle

