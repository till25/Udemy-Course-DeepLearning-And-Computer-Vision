from sklearn.feature_extraction.text import CountVectorizer
from sklearn.externals import joblib
import pandas as pd

def gender_predictor(names):
    df = pd.read_csv('bonusclf/names_dataset.csv')
    df_X = df.name 
    df_Y = df.sex

    cv = CountVectorizer()
    X = cv.fit_transform(df_X)

    nb_model = open('bonusclf/nbmodel.pkl', 'rb')
    clf = joblib.load(nb_model)
    vect = cv.transform(names).toarray()
    my_prediction = clf.predict(vect)
    if my_prediction == 0:
        return 'Female'
    return 'Male'

mine = gender_predictor(['Jane'])
print(mine)